<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>About Us - TINTA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      padding-top: 70px;
      background: linear-gradient(135deg, #f9f1ff, #ffffff);
      font-family: 'Segoe UI', sans-serif;
      color: #4a4a4a;
    }

    .navbar {
      background-color: #6f42c1;
    }

    .navbar a {
      color: white !important;
    }

    .navbar a:hover {
      color: #d6b8ff !important;
    }

    h1, h2 {
      color: #6f42c1;
      font-weight: 700;
    }

    .content-section {
      max-width: 900px;
      margin: 0 auto;
      padding: 40px 20px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(111, 66, 193, 0.15);
      margin-bottom: 40px;
    }

    p {
      font-size: 1.1rem;
      line-height: 1.6;
      margin-bottom: 20px;
    }

    label {
      font-weight: 600;
      color: #6f42c1;
    }

    .form-control:focus {
      border-color: #6f42c1;
      box-shadow: 0 0 8px rgba(111, 66, 193, 0.3);
    }

    .btn-primary {
      background-color: #6f42c1;
      border: none;
      font-weight: 600;
    }

    .btn-primary:hover {
      background-color: #532a8c;
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #6f42c1;
      color: white;
      margin-top: 60px;
    }

    @media (max-width: 576px) {
      .content-section {
        padding: 30px 15px;
      }
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="index.php">TINTA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon bg-light"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="shop.php">What We Offer</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="about_us.php">About Us</a></li>
        <li class="nav-item"><a class="nav-link" href="welcome.php">Account</a></li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
  <section class="content-section mt-5">
    <h1>About TINTA</h1>
    <p>
      Welcome to <strong>TINTA (A TINT THAT TALKS)</strong>, your trusted destination for high-quality, stylish, and affordable lip products. Founded by Hannah and Armmiela, we believe makeup is a form of self-expression and confidence.
    </p>
    <p>
      Our mission is to empower you to express your unique beauty every day with lip products designed to complement every skin tone, personality, and occasion.
    </p>

    <h2>Company Information</h2>
    <p>
      TINTA is committed to providing quality products crafted with care. We operate with integrity, transparency, and passion to bring you the best beauty experience possible.
    </p>

    <h2>Contact Us</h2>
    <p>If you have any questions or need assistance, please fill out the form below or reach out to us directly:</p>
    <ul>
      <li><strong>Email:</strong> support@tinta.com</li>
      <li><strong>Phone:</strong> +63 912 345 6789</li>
    </ul>

    <form method="post" action="about_us.php" class="mt-4" style="max-width:600px;">
      <div class="mb-3">
        <label for="name" class="form-label">Your Name</label>
        <input type="text" class="form-control" id="name" name="name" required maxlength="100" />
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Your Email</label>
        <input type="email" class="form-control" id="email" name="email" required maxlength="100" />
      </div>
      <div class="mb-3">
        <label for="message" class="form-label">Your Message</label>
        <textarea class="form-control" id="message" name="message" rows="5" required maxlength="1000"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Send Message</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      $name = trim($_POST['name'] ?? '');
      $email = trim($_POST['email'] ?? '');
      $message = trim($_POST['message'] ?? '');

      if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $message) {
        echo '<div class="alert alert-success mt-4" role="alert">';
        echo "Thank you, " . htmlspecialchars($name) . "! Your message has been received.";
        echo '</div>';
      } else {
        echo '<div class="alert alert-danger mt-4" role="alert">';
        echo "Please fill in all fields correctly.";
        echo '</div>';
      }
    }
    ?>
  </section>
</div>

<footer>
  <p>© 2025 TINTA by Hannah and Armmiela. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
