<?php
session_start();

// Example cart items — in real app, load this from session or database
$cartItems = [
  [
    "name" => "Matte Lipstick - Bold Berry",
    "price" => 399,
    "quantity" => 2,
    "image" => "images/lipstick1.jpg"
  ],
  [
    "name" => "Glossy Shine - Peach Pop",
    "price" => 299,
    "quantity" => 1,
    "image" => "images/lipstick2.jpg"
  ]
];

// Calculate total
$total = 0;
foreach ($cartItems as $item) {
  $total += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Your Cart - TINTA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #f3e6ff, #ffffff);
      font-family: 'Segoe UI', sans-serif;
      padding-top: 80px;
    }
    .navbar, footer {
      background-color: #6f42c1;
    }
    .navbar-brand, .navbar-nav .nav-link, footer {
      color: white !important;
    }
    .cart-container {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 40px;
      border-radius: 14px;
      box-shadow: 0 12px 28px rgba(111, 66, 193, 0.1);
    }
    .cart-header {
      border-bottom: 3px solid #d6b8ff;
      margin-bottom: 30px;
    }
    .cart-item img {
      width: 100px;
      height: 100px;
      object-fit: cover;
      border-radius: 10px;
    }
    .cart-item h5 {
      color: #6f42c1;
      font-weight: 700;
    }
    .total-box {
      background: #f8f1ff;
      padding: 20px;
      border-radius: 12px;
      text-align: right;
      font-size: 1.2rem;
      font-weight: 600;
      color: #532a8c;
    }
    .btn-checkout {
      background-color: #6f42c1;
      color: white;
      font-size: 1.15rem;
      padding: 12px 30px;
      border-radius: 8px;
      transition: 0.3s ease;
    }
    .btn-checkout:hover {
      background-color: #532a8c;
    }
    footer {
      padding: 20px 0;
      text-align: center;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="index.php">TINTA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon bg-light"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="shop.php">Shop</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="cart-container mt-4">
  <div class="cart-header text-center">
    <h2>Your Shopping Cart</h2>
  </div>

  <?php foreach ($cartItems as $item): ?>
    <div class="row align-items-center cart-item mb-4">
      <div class="col-md-2">
        <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
      </div>
      <div class="col-md-6">
        <h5><?= htmlspecialchars($item['name']) ?></h5>
        <p>₱<?= number_format($item['price'], 2) ?> x <?= $item['quantity'] ?></p>
      </div>
      <div class="col-md-4 text-end">
        <p class="fw-bold">₱<?= number_format($item['price'] * $item['quantity'], 2) ?></p>
      </div>
    </div>
  <?php endforeach; ?>

  <div class="total-box mt-4">
    Total: ₱<?= number_format($total, 2) ?>
  </div>

  <div class="text-end mt-4">
    <a href="checkout.php" class="btn btn-checkout">Proceed to Checkout</a>
  </div>
</div>

<footer class="mt-5 text-white">
  <div class="container">
    <p class="mb-0">© 2025 Armmiela Beauty. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
