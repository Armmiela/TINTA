<?php

$products = [
  ["name" => "Matte Lipstick - Bold Berry", "price" => 399, "image" => "images/lipstick1.jpg", "recommended" => true],
  ["name" => "Glossy Shine - Peach Pop", "price" => 299, "image" => "images/lipstick2.jpg", "recommended" => false],
  ["name" => "Hydra Matte - Rose Nude", "price" => 349, "image" => "images/lipstick3.jpg", "recommended" => true],
  ["name" => "Velvet Cream - Coral Charm", "price" => 279, "image" => "images/lipstick4.jpg", "recommended" => false],
];

// Add placeholders to reach 20 items total
$placeholderCount = 20 - count($products);
for ($i = 0; $i < $placeholderCount; $i++) {
    $products[] = [
        "name" => "Coming Soon",
        "price" => 0,
        "image" => "images/placeholder.png", // Add your generic placeholder image here
        "recommended" => false,
        "placeholder" => true
    ];
}

$sort = $_GET['sort'] ?? 'newest';
if ($sort === 'cheapest') {
  usort($products, fn($a, $b) => $a['price'] <=> $b['price']);
} elseif ($sort === 'recommended') {
  usort($products, fn($a, $b) => $b['recommended'] <=> $a['recommended']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>What We Offer - Armmiela Beauty</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      padding-top: 70px;
      background: linear-gradient(135deg, #f9f1ff, #ffffff);
      font-family: 'Segoe UI', sans-serif;
    }

    .navbar {
      background-color: #6f42c1;
    }

    .navbar a {
      color: white !important;
    }

    .navbar a:hover {
      color: #d6b8ff !important;
    }

    h1 {
      color: #6f42c1;
      font-weight: 700;
    }

    .sort-bar {
      margin-bottom: 30px;
      padding-top: 20px;
    }

    .product-card {
      border: none;
      border-radius: 16px;
      padding: 20px;
      text-align: center;
      background: white;
      box-shadow: 0 8px 20px rgba(111, 66, 193, 0.15);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      position: relative;
    }

    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 28px rgba(111, 66, 193, 0.25);
    }

    .product-card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 12px;
      margin-bottom: 15px;
    }

    .product-name {
      font-weight: 600;
      color: #6f42c1;
      font-size: 1.1rem;
      margin-bottom: 6px;
    }

    .product-price {
      color: #444;
      font-size: 1rem;
      margin-bottom: 15px;
    }

    .btn-primary {
      background-color: #6f42c1;
      border: none;
      font-weight: 600;
    }

    .btn-primary:hover {
      background-color: #532a8c;
    }

    .badge-recommended {
      position: absolute;
      top: 15px;
      right: 15px;
      background-color: #d6b8ff;
      color: #6f42c1;
      font-weight: 600;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 0.8rem;
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #6f42c1;
      color: white;
      margin-top: 60px;
    }

    /* Placeholder styling */
    .placeholder-card {
      opacity: 0.6;
      pointer-events: none;
    }
    .placeholder-card img {
      filter: grayscale(70%);
    }
    .btn-secondary {
      background-color: #aaa;
      border: none;
      color: #555;
      cursor: default;
    }
    .btn-secondary:hover {
      background-color: #aaa;
    }

    @media (max-width: 576px) {
      .product-card img {
        height: 180px;
      }
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="index.php">TINTA</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon bg-light"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="shop.php">What We Offer</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item">
          <a class="nav-link" href="welcome.php">Account</a>
        </li>
        <li class="nav-item"><a class="nav-link" href="cart.php">Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center sort-bar">
    <h1 class="mb-3 mb-md-0">Our Lip Products</h1>
    <form method="get" class="d-flex align-items-center">
      <label for="sort" class="me-2 fw-semibold text-dark">Sort by:</label>
      <select name="sort" id="sort" class="form-select" onchange="this.form.submit()">
        <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
        <option value="cheapest" <?= $sort === 'cheapest' ? 'selected' : '' ?>>Cheapest</option>
        <option value="recommended" <?= $sort === 'recommended' ? 'selected' : '' ?>>Most Recommended</option>
      </select>
    </form>
  </div>

  <div class="row g-4">
    <?php foreach ($products as $product): ?>
      <div class="col-lg-3 col-md-4 col-sm-6">
        <div class="product-card <?= !empty($product['placeholder']) ? 'placeholder-card' : '' ?>">
          <?php if (!empty($product['recommended'])): ?>
            <span class="badge-recommended">Recommended</span>
          <?php endif; ?>
          <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
          <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
          <div class="product-price">
            <?= !empty($product['placeholder']) ? '' : '₱' . number_format($product['price'], 2) ?>
          </div>
          <?php if(empty($product['placeholder'])): ?>
            <a href="#" class="btn btn-sm btn-primary">Add to Cart</a>
          <?php else: ?>
            <button class="btn btn-sm btn-secondary" disabled>Coming Soon</button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<footer>
  <p>© 2025 Armmiela Beauty. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
